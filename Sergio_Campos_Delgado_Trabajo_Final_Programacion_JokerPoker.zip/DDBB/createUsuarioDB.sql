CREATE USER 'programacion'@'localhost' IDENTIFIED BY 'programacion';
GRANT ALL PRIVILEGES ON *.* TO 'programacion'@'localhost' WITH GRANT OPTION;
